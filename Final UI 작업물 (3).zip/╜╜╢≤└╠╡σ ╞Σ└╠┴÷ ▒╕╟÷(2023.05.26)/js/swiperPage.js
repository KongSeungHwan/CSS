// Swiper 객체 생성
var swiper = new Swiper('.swiper-container', {
slidesPerView: 1,
spaceBetween: 0,
loop: true,
navigation: {
  nextEl: '.swiper-button-next',
  prevEl: '.swiper-button-prev',
},
});

// 메뉴바 링크 클릭 시 해당 슬라이드로 이동하는 함수
var links = document.querySelectorAll('.link');

links.forEach(function (link) {
link.addEventListener('click', function (e) {
  e.preventDefault();
  var slideIndex = parseInt(link.dataset.slide); // data-slide 속성 값을 가져옴
  swiper.slideTo(slideIndex); // 해당 슬라이드로 이동
  setActiveLink(slideIndex); // 메뉴바 버튼 활성화/비활성화 처리
});

link.addEventListener('mouseenter', function (e) {
  var slideIndex = parseInt(link.dataset.slide);
  setActiveLink(slideIndex);
});

link.addEventListener('mouseleave', function (e) {
  setActiveLink(null);
});
});

// 슬라이드 변경 시 링크 활성화/비활성화 처리
swiper.on('slideChange', function () {
var activeIndex = swiper.realIndex; // 현재 활성화된 슬라이드의 인덱스 가져오기
setActiveLink(activeIndex); // 메뉴바 버튼 활성화/비활성화 처리
});

// 활성화된 링크 스타일 설정 함수
function setActiveLink(activeIndex) {
var links = document.querySelectorAll('.link');
links.forEach(function (link) {
  link.classList.remove('active'); // 모든 버튼 비활성화
});

if (activeIndex !== null) {
  var activeLink = document.querySelector('.link[data-slide="' + activeIndex + '"]');
  activeLink.classList.add('active'); // 활성화된 버튼 스타일 적용
}
}
var swiperContainer = document.querySelector('.swiper-container');
var secondSlide = document.querySelector('.secondSlide');

if (swiperContainer && secondSlide) {
  secondSlide.addEventListener('click', function() {
    swiperContainer.style.display = 'block';
  });
}