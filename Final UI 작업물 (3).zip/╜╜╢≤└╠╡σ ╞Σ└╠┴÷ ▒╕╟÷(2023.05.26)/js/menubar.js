 // Swiper 객체 전역으로 선언
 var swiper = new Swiper('.swiper-container', {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });

  // 메뉴바 링크 클릭 시 해당 슬라이드로 이동하는 함수
  var links = document.querySelectorAll('.link');
  links.forEach(function(link) {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      var slideIndex = parseInt(link.dataset.slide); // data-slide 속성 값을 가져옴
      swiper.slideTo(slideIndex); // 해당 슬라이드로 이동
    });
  });